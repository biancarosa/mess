import os

SERVER_NAME = os.getenv('SERVER_NAME', 'mess.ns')